
public class Registration {
	
	public String owner;
	public String license;
	
	public Registration(String owner, String license) {
		this.owner = owner;
		this.license = license;
	}
}
